#include <QObject>
#include <QtCore>
#include "opencv2/opencv.hpp"
#include <pylon/PylonIncludes.h>
#include <pylon/BaslerUniversalInstantCamera.h>

using namespace cv;
using namespace std;
using namespace Pylon;
using namespace GenApi;
using namespace Basler_UniversalCameraParams;

//clase que hereda de la clase "hilos"
class CVideoAcquisition : public QThread
{
	Q_OBJECT 

private:
	//variables de la clase de acceso privado
	CBaslerUniversalInstantCamera* Camera; //variable para gestionar la captura de imagenes 	
	CImageFormatConverter FormatConverter; //variable para conversi�n de formatos
	CGrabResultPtr PtrGrabResult; //variable para guardar el resultado de la captura
	CPylonImage PylonImage; //variable para guardar la imagen de la c�mara
	Mat OpenCvImage; //variable para guardar la �ltima imagen en formato OpenCv	
	bool Recording; //variable para indicar si se est� grabando
	
	//m�todo que se ejecutar� cuando se llame a la funci�n start de esta clase
	void run();

public:
	//constructor por defecto
	CVideoAcquisition();

	//destructor
	~CVideoAcquisition();

	bool CameraOK; //variable para indicar si se ha realizado la comunicaci�n con la c�mara

	Mat GetImage(); //funci�n que devuelve la �ltima imagen
	void SetCameraAutoExposure(); //funci�n para poner en automatico el tiempo de exposici�n
	void SetCameraExposure(double exposure); //funci�n para cambiar el tiempo de exposici�n
	
signals:	
	//se�al que se produce cada vez que hay una nueva imagen disponible
	void NewImageSignal(Mat Img);

public slots:	
	//slot para ejecutar/parar la adquisici�n de im�genes
	void StartStopCapture(bool StartCapture);
};