#pragma once
#include <QObject>
#include <QString>
#include <QDir>
#include <atomic>
#include <vector>

// Estructura simple para pasar configuraci�n
struct TrainingConfig {
    QString rawFolder;       // Entrada: Im�genes Raw
    QString segFolder;       // Salida: Im�genes Recortadas
    QString featuresFile;
	QString templatesFolder;
    QString modelFile;
    QString evaluationFolder;
	bool skipSegmentation;
    bool skipExtraction;
	bool skipTemplates;
    bool skipTraining;
    bool skipEvaluation;
};

class TrainingWorker : public QObject {
    Q_OBJECT

public:
    explicit TrainingWorker(TrainingConfig config, QObject* parent = nullptr)
        : QObject(parent), cfg(config) {
        stopRequested.store(false);
    }

public slots:
    void process();  // El m�todo principal que arranca todo
    void stop() { stopRequested.store(true); }

signals:
    // Actualizar barras de progreso (0 a 100)
    void progressSeg(int percent);
    void progressExtract(int percent);
	void progressTemplates(int percent);
    void progressTrain(int percent);
	void progressEval(int percent);

    // Mensajes para el log (texto negro)
    void logMessage(QString msg);

    // Se�al final
    void finished();

private:
    TrainingConfig cfg;
    std::atomic<bool> stopRequested;

    // Pasos internos
    void runStepSegmentation();
    void runStepExtraction();
    void runStepTemplates();
    void runStepTraining();
    void runStepEvaluation();
};